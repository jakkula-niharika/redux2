import React, { Component } from 'react';
import './App.css';
import Counter from './store/components/Counter';

class App extends Component {
  render() {
    return (
      <div className="App">
       <h1>Redux Demo</h1>
       <Counter/>
      </div>
    );
  }
}

export default App;
