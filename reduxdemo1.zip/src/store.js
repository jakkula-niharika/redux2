import { createStore } from "redux";
import  counterReducer  from './store/reducers/CounterReducer';

const AppWithstore = createStore(counterReducer);

export default AppWithstore;
