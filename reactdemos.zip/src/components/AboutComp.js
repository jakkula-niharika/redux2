import React, {Component} from 'react'
export class About extends Component
{
    render()
    {
        return(
            <div>
            <h1>Hello from About component</h1>
            </div>
        )
    }
}

export default About;



