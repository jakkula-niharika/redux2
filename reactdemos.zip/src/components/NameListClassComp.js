import React,{ Component } from 'react'

class NameListClassComp extends React.Component
{
    render(props)
    {
        return(
            <div>
           <p>Name :  {this.props.user.name} </p>
           <p>Age :  {this.props.age} </p>
           <div>
               <h3>Hobbies :</h3>
            <ul>
                {this.props.user.hobbies.map((hobby)=><li>{hobby}</li>)}
            </ul>
            {this.props.children}
            </div>
            </div>
        )
    }
}
export default NameListClassComp