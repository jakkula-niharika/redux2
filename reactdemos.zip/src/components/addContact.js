import React, { Component } from "react";
import ShowContact from "./showContact";

export class AddContact extends Component {
   contactname= React.createRef();
   contactnumber = React.createRef();

   handleAddContact=()=>{
       let contObject = {contactname: this.contactname.current.value , 
        contactnumber: this.contactnumber.current.value}
       this.props.addContact(contObject)
   };
  
  render() {
    return (
      <div>
        <h1>Add Contact</h1>
        <form>
                <div className="container">
                    <label>ContactName:</label>
                    <input type="text" ref={this.contactname}/>
                </div>
                <div>
                    <label>ContactNumber:</label>
                    <input type="text" ref={this.contactnumber}/>
                </div>
                
                <button className="btn btn-primary" onClick={this.handleAddContact}> Add </button>
            </form>
            
      </div>
    );
  }
}

export default AddContact;
