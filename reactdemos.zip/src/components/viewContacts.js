import React, { Component } from "react";
import AddContact from "./addContact";
import ShowContact from "./showContact";
import axios from "axios";
export class viewContacts extends Component {
  state = { contacts: [] };
  baseUrl = " http://localhost:3000/contacts";

  getContacts = () => {
    axios.get(this.baseUrl).then(response => {
      this.setState({ contacts: response.data });
    });
  };
  addContact = contact => {
    axios.post(this.baseUrl, contact).then(response => {
      this.getContacts();
      alert("Contact Added");
    });
  };

  deleteContact = id => {
    alert("contact id: " + id);
    axios.delete(this.baseUrl+"/"+ id).then(
      res => {
        this.getContacts();
      },
      err => {
        this.setState({ errors: err });
      }
    );
  };

  componentDidMount() {
    this.getContacts();
  }

  render() {
    return (
      <div>
        <h1 className="page-header"> Manage Contacts</h1>
        <AddContact addContact={contact => this.addContact(contact)} />
        <br />
        <ShowContact contacts={this.state.contacts} deleteContact={this.deleteContact}/>
      </div>
    );
  }
}

export default viewContacts;
