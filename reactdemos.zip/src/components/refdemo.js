import React, {Component} from 'react'
export class RefDemo extends Component
{  
    constructor(props) {
    super(props);
    //step1
    // create a ref to store the textInput DOM element
    this.inputRef = React.createRef();
 }
 //similar to onInit --step3
  componentDidMount(){
      this.inputRef.current.focus();
  }
    render()
    {
       return(
          
           <div>
               <input type="text" ref={this.inputRef}  />
               <button>Click</button>
           </div>
       )
    } 
}

export default RefDemo;