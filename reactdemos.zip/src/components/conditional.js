import React, { Component } from "react";

export class conditional extends Component {
  constructor() {
    super();
    this.state = { display: false };
  }
  onChange = () => {
    this.setState({ display: !this.state.display });
  };

  render() {
    return (
      <div>
        <button onClick={this.onChange}>Change image</button>
        <br />
        {this.state.display ? (
          <img src={require("./rose.jpg")} />
        ) : (
          <img src={require("./lone.jpg")} />
        )}
      </div>
    );
  }
}

export default conditional;
