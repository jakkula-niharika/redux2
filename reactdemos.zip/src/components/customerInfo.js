import React from 'react'
import CustomerDisplay from './customerdisplay'
class CustomerInfo extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            user: {
                userName: '',
                userEmail: '',
                userMobile: '',
                userAddress: '',
                userDescription: '',
                userDateofVisit: ''
            }//user end
        }//state end

    }//constructor end

    handleSubmit = (event) => {
        const {user}=this.state;
        event.preventDefault();
        alert(`${user.userName}`)
        console.log(`${user.userName} ${user.userEmail} ${user.userMobile} ${user.userAddress} ${user.userDescription} ${user.userDateofVisit} `);
        this.setState({display: true});
    }

    UpdateState=(ctrl,value)=>{
        const {user}= this.state;//get the current state value
        user[ctrl]= value; //update the user entered values into ctrl
        this.setState({user}); 
    }
    resetState()
    {
      this.setState({
        user: {
            userName: '',
            userEmail: '',
            userMobile: '',
            userAddress: '',
            userDescription: '',
            userDateofVisit: ''
        },
        display: false
      })   
    }
    render() {
        const { user } = this.state;
        return (
            <div>
                <h1>State Add and Delete</h1>

                <form onSubmit={this.handleSubmit}>

                    <label>User Name:</label>
                    <input type="text" value={user.userName} onChange={(e) => this.UpdateState('userName', e.currentTarget.value)} />
                    <br />

                    <label>Email:</label>
                    <input type="text" value={user.userEmail} onChange={(e) => this.UpdateState('userEmail', e.currentTarget.value)} />
                    <br />

                    <label>Mobile:</label>
                    <input type="text" value={user.userMobile} onChange={(e) => this.UpdateState('userMobile', e.currentTarget.value)} />
                    <br />

                    <label>Address:</label>
                    <input type="text" value={user.userAddress} onChange={(e) => this.UpdateState('userAddress', e.currentTarget.value)} />
                    <br />

                    <label>Description:</label>
                    <input type="text" value={user.userDescription} onChange={(e) => this.UpdateState('userDescription', e.currentTarget.value)} />
                    <br />

                    <label>User Date of visit:</label>
                    <input type="text" value={user.userDateofVisit} onChange={(e) => this.UpdateState('userDateofVisit', e.currentTarget.value)} />
                    <br />

                    <button type="submit">Submit</button>
                </form>
               { 
                   this.state.display ?
               <CustomerDisplay userData={this.state.user} deleteCustomer={(e)=>this.resetState()} />:
                null
                }
            </div>
        )
    }
}
export default CustomerInfo;