import React from 'react';

export class GreetingClassComponent extends React.Component
{

render()
{
    return (<h1>Hello  Ginu</h1>)
}
}
export default GreetingClassComponent