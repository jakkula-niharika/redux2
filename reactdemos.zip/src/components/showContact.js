import React, { Component } from 'react'

export class ShowContact extends Component {
  render() {
    return (
      <div>
         {/* <h1>Show Contact</h1> */}
         <table  className="table table-bordered">
             <thead>
                 <th>Contact Name</th>
                 <th>Contact Number</th>

             </thead>
        
                 {this.props.contacts.map((contacts)=>
                     <tbody>
                     <tr key={contacts}>
                         <td>{contacts.contactname}</td>
                         <td>{contacts.contactnumber}</td>
                         <td>
                             <button className="btn btn-danger" onClick={()=>this.props.deleteContact(contacts.id)}>X</button>
                         </td>
                         </tr>
                         </tbody>
                 )}
            
         </table>
      </div>
    )
  }
}

export default ShowContact
