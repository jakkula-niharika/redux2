import React, {Component} from 'react'
export class PageNotFound extends Component
{
    render()
    {
        return(
            <div>
            <h1>Page Not Found</h1>
            <h2>404 Error</h2>
            </div>
        )
    }
}

export default PageNotFound;