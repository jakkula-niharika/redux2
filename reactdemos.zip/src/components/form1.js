import React, {Component} from 'react'
export class Form1 extends Component
{   constructor(props) {
    super(props)
        this.state={
            name:'',
            displayname:''
        }
       
    }
   
    handleSubmit=(event)=>{
       
        this.setState({
            displayname: this.state.name.toUpperCase()
            
        });
         
       event.preventDefault();
    }
    handlechangename=(event)=>{
        this.setState({
            name: event.target.value
            //use event.target.value.toUppercase if wanted the value to be in uppercase
        });
    }
    render()
    {
        return(
            <div>
            <form onSubmit={this.handleSubmit}>
                <div>
                   <h1>{this.state.displayname}</h1>
                    <label>Name:</label>
                    <textarea value={this.state.name} onChange={this.handlechangename}/>
                    <button type="submit">Click</button>
                </div>
                </form>
            </div>
        )
    }
}

export default Form1;