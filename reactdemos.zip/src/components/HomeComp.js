import React, {Component} from 'react'
export class Home extends Component
{
    render()
    {
        return(
            <div>
            <h1>Hello from Welcome component</h1>
            <img src={require ('./image.jpg')} />
            </div>
        )
    }
}

export default Home;