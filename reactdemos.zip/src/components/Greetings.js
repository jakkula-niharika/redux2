import React from 'react';

//functional component
const Greeting =(props)=>{
    return <h1>Hello {props.name}</h1>
}
export default Greeting;