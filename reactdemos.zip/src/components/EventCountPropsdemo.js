import React from 'react';

export class EventCountProps extends React.Component
{
    Updateage()
    {
        this.age = this.props.age;
        console.log('Before Update age is '+this.age);
        this.age += 5;
        console.log('After Update age is '+this.age);
    }
    render()
    {
        return(
            <div>
                <h1>{this.props.age}</h1>
    <button onClick={()=> this.Updateage()}>Increment </button>
    </div>
        )  
}
}
export default EventcountProps