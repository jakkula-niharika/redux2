import React from 'react';

export class EventUpdateC extends React.Component
{
    constructor(props){
        super();
        this.age=props.age;
    }
    onUpdate()
    {
        console.log('Before Update '+this.age);
        this.age+=5;
        console.log('After Update '+this.age);
    }
    render()
    {
        return(
    <button onClick={()=> this.onUpdate()}>Update Age (constructor) </button>)
    }
}
export default EventUpdateC;