import React,{ Component } from 'react'

export const Funclassdemo=()=>
{
    return<h1>This is my functional component</h1>
}
export default Funclassdemo;