import React from 'react'
class CustomerDisplay extends React.Component
{
    render(){
       const user=this.props.userData
        return(
            <div>
                <h1>Display the customer information</h1>
               <p>Name: {user.userName}</p> 
               <p>Email: {user.userEmail}</p> 
               <p>Mobile: {user.userMobile}</p>
               <p>Address: {user.userAddress}</p>
               <p>Description: {user.userDescription}</p>   
               <p>DateOfVisit: {user.userDateofVisit}</p> 
               <button onClick={()=>this.props.deleteCustomer()} >Delete</button>
            </div>
        )
    }
}
export default CustomerDisplay;