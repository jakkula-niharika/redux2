import React, { Component } from "react";

export class parent extends Component {
  render() {
    return (
      <div>
        <h1>Am Parent</h1>
        <p>{this.props.children.length}</p>
        <p>{this.props.children}</p>
        <div>
          {this.props.children.map(element => 
            <p>{element.type}</p>
          )}
        </div>
      </div>
    );
  }
}

export default parent;



//for assignment
//then add the below code in app.js
{/* <parent>
    <div>
    <button>register</button>
    <br/>
    <h1>This is sample component</h1>
    </div>
</parent> */}