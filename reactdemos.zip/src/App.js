import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import {Welcome} from './components/Welcome';
import {Funclassdemo} from './components/Funclassdemo';
import Greeting from './components/Greetings';
import GreetingClassComponent from './components/Greetingclassdemo';
import NumListClassComp from './components/NumListClassComp';
import NameListClassComp from './components/NameListClassComp';
import EventDemo1 from './components/Event-demo1';
import EventUpdateC from './components/Event-propsupdateconstructer';
import EventProps from './components/Event-props';
import StateDemo from './components/statedemo';
import {BrowserRouter as Router, Route, Link, Switch} from 'react-router-dom';
import Home from './components/HomeComp';
import About from './components/AboutComp';
import Form from './components/form';
import Form1 from './components/form1';
import RefDemo from './components/refdemo';
import Header from './components/Header';
import customerInfo from './components/customerInfo';
import lifecycleA from './components/lifecycleA';
import viewContacts from './components/viewContacts';
import conditional from './components/conditional';

class App extends Component {
  render() {
    let numbers  = [11,12,13,14,1];
    let user = {
      name : "Jakkula Niharika",
    hobbies : ["Batminton","Basket Ball","Shopping", "Watching Movies"]
    }
    return (
      <Router>
      <div>
<Header/>
<div className="container">
<Switch>
        <Route exact path='/' component={Home}></Route>
        <Route extact path='/about' component = {About}></Route>
        <Route extact path='/form' component = {Form}></Route>
        <Route extact path='/form1' component = {Form1}></Route>
        <Route extact path='/refdemo' component = {RefDemo}></Route>
        <Route extact path='/customer-info' component = {customerInfo}></Route>
        <Route extact path='/lifecycleA' component = {lifecycleA}></Route>
        <Route extact path='/viewContacts' component = {viewContacts}></Route>
        <Route extact path='/conditional' component = {conditional}></Route>
      </Switch>
</div>

</div>
</Router>
    );






{/* <div className = "container">
  <div className= "row">
    <div className ="col-xs=12">
    <BrowserRouter>
    <div>
      <ul>
        <li>
          <Link to="/">Home</Link>
        </li>
        <li>
          <Link to="/about">About</Link>
        </li>
      </ul>
    </div>
    <div>
      <Switch>
        <Route exact path='/' component={Home}></Route>
        <Route extact path='/' component = {About}></Route>
      </Switch>
    </div>
    </BrowserRouter>
    </div>
  </div>
</div> */}




      // <div className = "container">
      //   <div className = "row">
      //     <div className = "col-xs-12">
           // <Greeting name="Ginu"/>
           // <Greeting name="Dinu"/>
           // <Greeting name ="Linu"/> 
          //  <hr/>
       // <GreetingClassComponent/> 
          // <hr/> 
            {/* <NumListClassComp numbers = {numbers}/> */}
            {/* <hr/> */}
            {/* <NameListClassComp name = {user.name} age = {30} user = {user}> 
          <h3>This is from child </h3> 
          </NameListClassComp> */}
          {/* <hr/>
          <EventDemo1 />
          <hr/>
          <EventUpdateC age={32}/>
            <hr/>  */}
            {/* <EventProps age = {32}/>
            <StateDemo message = {"Welcome Guest"}/>
          </div>
        </div>
      </div> */}
      
      // <div>
     // { <h1>Hello Welcome to My App</h1> }
      //{ <h1>This is another tag</h1> }
     // { <Welcome/> }
      //{<Funclassdemo/> }
      //</div>


      // <div className="App">
      //   <header className="App-header">
      //     <img src={logo} className="App-logo" alt="logo" />
      //     <p>
      //       Edit <code>src/App.js</code> and save to reload.
      //     </p>
      //     <a
      //       className="App-link"
      //       href="https://reactjs.org"
      //       target="_blank"
      //       rel="noopener noreferrer"
      //     >
      //       Learn React
      //     </a>
      //   </header>
      // </div>
    
  }
}

export default App;
